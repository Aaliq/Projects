This project is an augmented reality game designed using spark AR studio and requires that specifice software to open the Prototype 2.arexport file

The software can be downloaded from
https://sparkar.facebook.com/ar-studio/download/

We have also included all the resources used in this project as a separate folder.
